package com.example.listvew;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    ArrayList<String> food;
    ArrayList<Integer> list;
    private ListView listView;
    private ImageView imageView;
    ArrayAdapter<String> adapter;

    @SuppressLint({"WrongViewCast", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        list=new ArrayList<>();
        list.add(R.drawable.pizza);
        list.add(R.drawable.burger);
        list.add(R.drawable.chicken);
        list.add(R.drawable.rise);
        food = new ArrayList<>();
        food.add("pizza");
        food.add("burger");
        food.add("chicken");
        food.add("rice");
        imageView=findViewById(R.id.imageView);

        adapter= new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,food);
        listView=findViewById(R.id.list);
        listView.setAdapter(adapter);
       listView.setOnItemClickListener(this);

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
        Toast.makeText(this,"click:"+food.get(i),Toast.LENGTH_SHORT).show();
        imageView.setImageResource(list.get(i));

    }


}